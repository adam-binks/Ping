#pragma once

// Auto Generated File, do not edit!
// It will be updated whenever we update unity version
// When unity version is changed:
//   UNITY_VERSION value will be changed
//   UNITY_X_Y_Z for this new version will be added

#define UNITY_VERSION 462

// known unity versions
#define UNITY_4_2_0 420
#define UNITY_4_2_1 421
#define UNITY_4_2_2 422
#define UNITY_4_3_0 430
#define UNITY_4_3_1 431
#define UNITY_4_3_3 433
#define UNITY_4_5_0 450
#define UNITY_4_5_1 451
#define UNITY_4_5_2 452
#define UNITY_4_5_3 453
#define UNITY_4_5_4 454
#define UNITY_4_6_0 460
#define UNITY_4_6_1 461
#define UNITY_4_6_2 462
